import React from "react";
const TextErr = (props) => {
  return <div style={{ color: "red" }}>{props.children}</div>;
};
export default TextErr;
